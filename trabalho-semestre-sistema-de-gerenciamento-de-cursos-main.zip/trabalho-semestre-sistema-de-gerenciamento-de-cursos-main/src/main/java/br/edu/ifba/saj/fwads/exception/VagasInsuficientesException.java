package br.edu.ifba.saj.fwads.exception;

public class VagasInsuficientesException extends Exception {
    public VagasInsuficientesException(String message) {
        super(message);
    }
}