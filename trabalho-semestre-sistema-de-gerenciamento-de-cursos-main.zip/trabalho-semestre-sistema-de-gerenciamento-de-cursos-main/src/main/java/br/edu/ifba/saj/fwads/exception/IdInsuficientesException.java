package br.edu.ifba.saj.fwads.exception;

public class IdInsuficientesException extends Exception {
    public IdInsuficientesException(String message) {
        super(message);
    }
}