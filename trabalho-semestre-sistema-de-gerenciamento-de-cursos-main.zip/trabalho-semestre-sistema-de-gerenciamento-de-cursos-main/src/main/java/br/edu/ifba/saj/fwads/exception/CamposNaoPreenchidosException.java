package br.edu.ifba.saj.fwads.exception;

public class CamposNaoPreenchidosException extends Exception {
    public CamposNaoPreenchidosException(String message) {
        super(message);
    }
}