package br.edu.ifba.saj.fwads.exception;

public class TurmaInvalidaException extends Exception {
    public TurmaInvalidaException(String message) {
        super(message);
    }
}
