package br.edu.ifba.saj.fwads.exception;

public class LoginInvalidoException extends Exception {
    public LoginInvalidoException(String msg){
        super(msg);
    }    
}