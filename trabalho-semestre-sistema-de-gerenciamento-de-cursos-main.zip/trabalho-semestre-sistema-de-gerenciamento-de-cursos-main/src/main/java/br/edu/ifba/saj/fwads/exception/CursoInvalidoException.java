package br.edu.ifba.saj.fwads.exception;

public class CursoInvalidoException extends Exception {
    public CursoInvalidoException(String message) {
        super(message);
    }
}
